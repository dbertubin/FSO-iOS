//
//  plannerTests.h
//  plannerTests
//
//  Created by Derek Bertubin on 11/4/12.
//  Copyright (c) 2012 Derek Bertubin. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface plannerTests : SenTestCase

@end

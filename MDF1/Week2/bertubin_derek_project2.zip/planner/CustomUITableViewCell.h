//
//  CustomUITableViewCell.h
//  planner
//
//  Created by Derek Bertubin on 11/26/12.
//  Copyright (c) 2012 Derek Bertubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomUITableViewCell : UITableViewCell


@property IBOutlet UILabel * mainLabel;

@property IBOutlet UILabel * subTextLabel;

@end
